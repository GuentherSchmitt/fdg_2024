import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  BoxedValue<double> boxedAngleX = BoxedValue(0);
  BoxedValue<double> boxedAngleY = BoxedValue(0);
  double angleZ = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
              seedColor: Colors.blue, surface: Colors.blue.shade100)),
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          title: const Text("Transform with 3 axis",
              style: TextStyle(fontSize: 24)),
          centerTitle: true,
          leading: const Padding(
            padding: EdgeInsets.all(8.0),
            child: CircleAvatar(
                foregroundImage: AssetImage("assets/images/flutter_logo.jpg")),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.rotationZ(angleZ),
                    child: Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.rotationY(boxedAngleY.value),
                        child: Transform(
                          alignment: Alignment.center,
                          transform: Matrix4.rotationX(boxedAngleX.value),
                          child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(20)),
                              child: Image.asset(
                                  "assets/images/snoopy_laptop.jpg",
                                  width: 230)),
                        )),
                  ),
                  const SizedBox(width: 20),
                  Image.asset("assets/images/axis.jpg", width: 130),
                ],
              ),
              getAxisSlider("x-Axis", Colors.red, boxedAngleX),
              getAxisSlider("y-Axis", Colors.green, boxedAngleY),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      boxedAngleX.value = 0;
                      boxedAngleY.value = 0;
                      angleZ = 0;
                    });
                  },
                  child: const Text("Reset"))
            ],
          ),
        ),
      ),
    );
  }

  Row getAxisSlider(String title, Color color, BoxedValue<double> boxedAngle) {
    return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: TextStyle(color: color)),
                Slider(
                  value: boxedAngle.value,
                  min: -2 * pi,
                  max: 2 * pi,
                  onChanged: (value) {
                    setState(() {
                      boxedAngle.value = value;
                    });
                  },
                ),
              ],
            );
  }
}

class BoxedValue<T> {
  BoxedValue(this.value);
  T value;
}